<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Lightninghoof PvE Rankings</title>
<style type="text/css"> 	
body{
	padding: 20px;
	background-color: #000000;
	font: 11px "Trebuchet MS",Verdana,Arial,sans-serif;
	background-image: url(rankingbg.jpg);
	/**background:url(./images/<?= "gentlemansun".rand(1,8).".jpg"; ?>);**/
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
h1,h2,p{margin: 0 10px}
h1{font-size: 250%;color: #FFF}
h2{font-size: 200%;color: #f0f0f0}
.subtitle{font-size: 150%;color: #FFF}
p{padding-bottom:1em;color: #FFF}
h2{padding-top: 0.3em}
img{}
div#nifty{ 
	margin: 0 5%;
	background: #000000;
	opacity:.80;
	width:90%;
	filter:alpha(opacity=80);
}
img {
	text-align: center;
	margin: 5px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
div#nifty2{ 
	margin: 0 5%;
	background: #000000;
	width:90%;
}
b.rtop, b.rbottom{display:block;background: #461A3A}
b.rtop b, b.rbottom b{display:block;height: 1px;
    overflow: hidden; background: #000000}
b.r1{margin: 0 5px}
b.r2{margin: 0 3px}
b.r3{margin: 0 2px}
b.rtop b.r4, b.rbottom b.r4{margin: 0 1px;height: 2px}
body,td,th {
	font-size: 11px;
	color: #FFFFFF;
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
td:a:link {
	color: #FF9900;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FF9900;
}
a:hover {
	text-decoration: underline;
	color: #FF9900;
}
a:active {
	text-decoration: none;
	color: #FF9900;
}

a.info{
    position:relative; /*this is the key*/
    z-index:24; 
	/*background-color:#000;*/
    color:#FFF;
    text-decoration:none
	font-size: 50%
	}
a.infoblack{
    position:relative; /*this is the key*/
    z-index:24; 
	/*background-color:#000;*/
    color:#000;
    text-decoration:none
	font-size: 50%
}
a.info:hover{z-index:25; background-color:#FF9900}

a.info span{display: none}

a.info:hover span{ /*the span will display just on :hover state*/
    display:block;
    position:absolute;
    top:1em; left:0em; width:20em;
    border:1px solid #666;
    background-color:#FFF; color:#000;
    text-align: center}
.style1 {color: #FF3300 !important}
.centered {
	text-align: center;
}
</style>
<script type="text/JavaScript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
</head>
<body>
<div id="nifty">
<b class="rtop"><b class="r3"></b></b>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="50%"><h1>Lightninghoof Server Info</h1></td>
    <td width="50%" align="right" valign="top"><span class="subtitle">Welcome, Moonmaster of Sublime! <a href="#" class="style1">Logout.</a></span>
	  <br /></td>
  </tr>
</table>
<b class="rtop"><b class="r2"></b></b>
<p>Hosted by <a href="http://www.techotter.com"><u>techotter.com</u></a> - More features coming soon! <b class="rtop"><b class="r4"></b></b><br />
  <span class="style1">New!</span>Check out the new <a href="#photostream"><u>Lightninghoof photostream</u></a> at the bottom of the page!</p>
<p> Hover over a guild name to see guild info.  Click a guild name to see the Armory Profile.<br />
  Hover over a boss' abbreviation to see that boss' full name.</p>
<table width="100%" border="0" cellspacing="1" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="14" bgcolor="#0099FF"><div align="center">Karazhan</div></td>
    <td colspan="2" bgcolor="#00FF00"><div align="center">Gruul</div></td>
    <td bgcolor="#CCFF33"><div align="center">Mag</div></td>
    <td colspan="5" bgcolor="#FFCC00"><div align="center">Serpentshrine</div></td>
    <td colspan="2" bgcolor="#FF6600">World</td>
    <td><div align="center">Total</div></td>
  </tr>
  <tr>
    <td colspan="4" width="400">Guild Name </td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Be<span>Named Beast</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">At<span>Attumen the Hunter</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Mo<span>Moroes</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Ma<span>Maiden of Virtue</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Cu<span>The Curator</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Il<span>Terrestrian Illhoof</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Sh<span>Shade of Aran</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Ne<span>Netherspite</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Wi<span>Wizard of Oz</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Li<span>Little Red Riding Hood</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Ro<span>Romulo & Julianne</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Ch<span>Chess Event</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Pr<span>Prince Malchezaar</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Ni<span>Nightbane</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Hi<span>High King Maulgar</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Gr<span>Gruul</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Mag<span>Magtheridon</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Hy<span>Hydross the Unstable</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Fa<span>Fathom-Lord Karathress</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Mo<span>Morogrim Tidewalker</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Le<span>Leotheras the Blind</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Va<span>Lady Vashj</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Ka<span>Doom Lord Kazzak</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Do<span>Doomwalker</span></a></td>
    <td><div align="center"></div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#0033CC"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Cadia" class="info">1. Cadia<span>
		http://www.cadiaguild.com<BR />
		Guild Leader: Cydel </span></a></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center">245</div></td>
  </tr>
       <tr>
    <td colspan="4" bgcolor="#0033CC"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Fury" class="info">2. Fury<span>
		http://www.furypvp.com<br />
		Guild Leader: Archmagus</span></a></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center">220</div></td>
  </tr>
  <tr>
    <td colspan="4" bordercolor="#FFCC00" bgcolor="#FFCC33"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Sublime" class="info">2. Sublime<span>
		http://www.sublimewow.com<br />
	  Guild Leader: Zoot</span></a></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href="#"><img src=images/red.gif border=0 onclick="MM_openBrWindow('update.php','update','width=500,height=200')"></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href="#"><img src=images/red.gif border=0 onclick="MM_openBrWindow('update.php','update','width=300,height=200')"></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href="#"><img src=images/red.gif border=0 onclick="MM_openBrWindow('update.php','update','width=300,height=200')"></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href="#"><img src=images/red.gif border=0 onclick="MM_openBrWindow('update.php','update','width=300,height=200')"></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href="#"><img src=images/red.gif border=0 onclick="MM_openBrWindow('update.php','update','width=300,height=200')"></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href="#"><img src=images/red.gif border=0 onclick="MM_openBrWindow('update.php','update','width=300,height=200')"></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href="#"><img src=images/red.gif border=0 onclick="MM_openBrWindow('update.php','update','width=300,height=200')"></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center"><a href="#"><img src=images/red.gif border=0 onclick="MM_openBrWindow('update.php','update','width=300,height=200')"></a></div></td>
    <td bordercolor="#FFCC00" bgcolor="#FFCC33"><div align="center">220</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#0033CC"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Awakening" class="info">2. Awakening<span>
		http://www.awakeningwow.net<br />
	  Guild Leader: Tearian</span></a></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center">220</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Delusions+of+grandeur" class="info">5. Delusions of Grandeur<span>
		http://www.michealwass.us/dogguild/dgforum/<br />
		Guild Leader: Mendemic</span></a></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">195</div></td>
  </tr>
    <tr>
    <td colspan="4" bgcolor="#0033CC"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Leviticus" class="info">6. Leviticus<span>
		http://www.leviticus-guild.com<br />
	  Guild Leader: Adaera</span></a></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center">185</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#0033CC"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Finale" class="info">7. Finale<span>
		<br />
		Guild Leader: Ayashi</span></a></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center">175</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#0033CC"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Serotonin" class="info">8. Serotonin<span>
		http://touchedbyabear.guildportal.com<br />
		Guild Leader: Sakamoto</span></a></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center">150</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Redoubt" class="info">9. Redoubt<span>
		http://www.rd.clantournament.net<br />
		Guild Leader: Iresaint</span></a></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">135</div></td>
  </tr>
        <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Praetorian" class="info">9. Praetorian<span>
		http://www.guildpraetorian.net<br />
		Guild Leader: Waddell</span></a></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">135</div></td>
  </tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Be<span>Named Beast</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">At<span>Attumen the Hunter</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Mo<span>Moroes</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Ma<span>Maiden of Virtue</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Cu<span>The Curator</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Il<span>Terrestrian Illhoof</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Sh<span>Shade of Aran</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Ne<span>Netherspite</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Wi<span>Wizard of Oz</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Li<span>Little Red Riding Hood</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Ro<span>Romulo & Julianne</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Ch<span>Chess Event</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Pr<span>Prince Malchezaar</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Ni<span>Nightbane</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Hi<span>High King Maulgar</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Gr<span>Gruul</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Mag<span>Magtheridon</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Hy<span>Hydross the Unstable</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Fa<span>Fathom-Lord Karathress</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Mo<span>Morogrim Tidewalker</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Le<span>Leotheras the Blind</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Va<span>Lady Vashj</span></a></td>
    <td width="20" bgcolor="#333333">  <a href="#" class="info">Ka<span>Doom Lord Kazzak</span></a>    </td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Do<span>Doomwalker</span></a></td>
    <td><div align="center"></div></td>
  </tr>
   <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Fine+Young+Cannibals" class="info">11. Fine Young Cannibals<span>
		http://fyc.dkpsystem.com<br />
		Guild Leader: Tumult</span></a></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">125</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=How+We+Roll" class="info">12. How We Roll<span>
		Guild Info Unavailable.</span></a></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">110</div></td>
  </tr>
  <tr>
    <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Forest+of+Feelings" class="info">13. Forest of Feelings<span>
		http://warcrafted.com/bundy/index.php<br />
		Guild Leader: Htoo</span></a></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">105</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Primal" class="info">14. Primal<span>
		http://primal.oek.id.au<br />
		Guild Leader: Makaru</span></a></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">100</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#0033CC"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Symphony+of+blades" class="info">14. Symphony Of Blades<span>
		http://symphonyofblades.com<br />
	  Guild Leader: Ver</span></a></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center">100</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#0033CC"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Wrath" class="info">14. Wrath<span>
		http://www.wrathbastards.com<br />
	   Guild Leader: Kiamei</span></a></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center">100</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#0033CC"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=The+Crusade" class="info">17. Synergy<span>
		http://xavin.darkstargamers.com/forums<br />
		Guild Leader: Nahaz</span></a></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center">90</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#0033CC"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Prestige" class="info">17. Prestige<span>
		Guild Info Unavailable.</span></a></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center">90</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#0033CC"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Bane" class="info">17. Bane<span>
		http://www.wowbane.com<br />
	  Guild Leader: Sherixi</span></a></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC"><div align="center"></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center">90</div></td>
  </tr>
  <tr>
   <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Disdain" class="info">20. Disdain<span>
		http://www.disdainwow.com<br />
		Guild Leader: Flatiron</span></a></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">80</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Ravens+Fury" class="info">20. Raven's Fury<span>
		http://www.ravens-fury.com/forum<br />
		Guild Leader: Boedacious</span></a></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">80</div></td>
  </tr>
   <tr>
    <tr>
    <td colspan="4" bgcolor="#0033CC"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=House+Dragonmoon" class="info">20. House Dragonmoon<span>
	http://housedragonmoon.guildportal.com<br />
	Guild Leader: Kalena</span></a></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center">80</div></td>
  </tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Be<span>Named Beast</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">At<span>Attumen the Hunter</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Mo<span>Moroes</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Ma<span>Maiden of Virtue</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Cu<span>The Curator</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Il<span>Terrestrian Illhoof</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Sh<span>Shade of Aran</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Ne<span>Netherspite</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Wi<span>Wizard of Oz</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Li<span>Little Red Riding Hood</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Ro<span>Romulo & Julianne</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Ch<span>Chess Event</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Pr<span>Prince Malchezaar</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Ni<span>Nightbane</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Hi<span>High King Maulgar</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Gr<span>Gruul</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Mag<span>Magtheridon</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Hy<span>Hydross the Unstable</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Fa<span>Fathom-Lord Karathress</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Mo<span>Morogrim Tidewalker</span></a></td>
    <td width="20" bgcolor="#333333"><a href="#" class="info">Le<span>Leotheras the Blind</span></a></td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Va<span>Lady Vashj</span></a></td>
    <td width="20" bgcolor="#333333">  <a href="#" class="info">Ka<span>Doom Lord Kazzak</span></a>    </td>
    <td width="20" bgcolor="#666666"><a href="#" class="info">Do<span>Doomwalker</span></a></td>
    <td><div align="center"></div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Grievous" class="info">23. Grievous<span>
		http://www.clangrievous.com<br />
		Guild Leader: Solomon</span></a></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">60</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Bone+Brigade" class="info">24. Bone Brigade<span>
	http://bonebrigade.us<br />
	Guild Leader: Versil</span></a></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">50</div></td>
  </tr>
   <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=invictus" class="info">24. Invictus<span>
		http://www.guildinvictus.com<br />
		Guild Leader: Hawkril</span></a></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">50</div></td>
  </tr>
    <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Tempest" class="info">24. Tempest<span>
		http://www.tempest-guilds.org<br />
		Guild Leader: Tigereye</span></a></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000"><div align="center"></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">50</div></td>
  </tr>
    <tr>
    <td colspan="4" bgcolor="#0033CC"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Naritus" class="info">27. Naritus<span>
		http://naritus.guildportal.com<br />
		Guild Leader: Kierra</span></a></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC">&nbsp;</td>
    <td bgcolor="#0033CC"><div align="center">40</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Visceral" class="info">28. Visceral<span>
		http://www.visceralguild.com<br />
		Guild Leader: Splatterhorn</span></a></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">10</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Army+of+Eternity" class="info">28. Army of Eternity<span>
		http://armyofeternity.ej.am<br />
		Guild Leader: Melkurian, Jarek, Exophus</span></a></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">10</div></td>
  </tr>
  <tr>
    <td colspan="4" bgcolor="#990000"><a href="http://armory.worldofwarcraft.com/#guild-info.xml?r=Lightninghoof&n=Unholy+Retribution" class="info">28. Unholy Retribution<span>
		http://s11.invisionfree.com/UnholyRetribution<br />
		Guild Leader: Aezekiel</span></a></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center"><a href=info.php><img src=images/green.gif border=0></a></div></td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000">&nbsp;</td>
    <td bgcolor="#990000"><div align="center">10</div></td>
  </tr>
</table>
<b class="rbottom"><b class="r4"></b><b class="r3"></b><b class="r2"></b><b class="r1"></b></b>
</div>
<div id="nifty2">
<b class="rtop"><b class="r3"></b></b>
<h1><a name="photostream" id="photostream">Lightninghoof Photostream <b class="rtop"><b class="r2"></b></b></h1>
<p><strong>How to submit screenshots:</strong> email your screenshots as attachments to <a href="mailto:paste07above@photos.flickr.com"><u>paste07above@photos.flickr.com</u></a> It may take a few minutes for the photostream to process your screenshot. <b>ONLY ONE SCREENSHOT PER EMAIL PLEASE :)</b></p>
<p class="style1">NOTE: Screenshots only please. This stream will be monitored, and other images will be removed.  </p><br />

<p class="centered"><script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=9&display=latest&size=m&layout=h&source=user&user=7636238%40N02"></script></p>
<b class="rbottom"><b class="r4"></b><b class="r3"></b><b class="r2"></b><b class="r1"></b></b>
</div>
</body>
</html>
