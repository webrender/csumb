<?php 
if (isset($_POST['submitted'])) {

	require_once('./config.php'); // Connect to the db.
	
	// Create a function for escaping the data.
	function escape_data ($data) {
		global $dblink; // Need the connection.
		if (ini_get('magic_quotes_gpc')) {
			$data = stripslashes($data);
		}
		return mysql_real_escape_string(trim($data), $dblink);
	} // End of function.
		
	$errors = array(); // Initialize error array.
	
	// Check for an email address.
	if (empty($_POST['username'])) {
		$errors[] = 'Please Enter a Username.';
	} else {
		$n = escape_data($_POST['username']);
	}
	
	// Check for a password.
	if (empty($_POST['password'])) {
		$errors[] = 'Please enter a Password.';
	} else {
		$p = escape_data($_POST['password']);
	}
	
	if (empty($errors)) { // If everything's OK.

		/* Retrieve the user_id and first_name for 
		that email/password combination. */
		$query = "SELECT username, password FROM guilds WHERE username='$n' AND password=SHA('$p') AND isadmin='1'";	
		//optional: 
		$result = @mysql_query ($query); // Run the query.
		$row = mysql_fetch_array ($result, MYSQL_NUM); // Return a record, if applicable.

		if ($row) { // A record was pulled from the database.
				
			// Set the session data & redirect.
			session_start();
			$_SESSION['user_id'] = $row[0];
			$_SESSION['first_name'] = $row[1];

			// Redirect the user to the loggedin.php page.
			// Start defining the URL.
			$url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
			// Check for a trailing slash.
			if ((substr($url, -1) == '/') OR (substr($url, -1) == '\\') ) {
				$url = substr ($url, 0, -1); // Chop off the slash.
			}
			// Add the page.
			$url .= '/guilds_edit.php';
			
			header("Location: $url");
			exit(); // Quit the script.
				
		} else { // No record matched the query.
			$errors[] = 'Invalid Username/Password.'; // Public message.
			//$errors[] = mysql_error() . '<br /><br />Query: ' . $query; // Debugging message.
		}
		
	} // End of if (empty($errors)) IF.
		
	//mysql_close(); // Close the database connection.
	
} else { // Form has not been submitted.

	$errors = NULL;

} // End of the main Submit conditional.

// Begin the page now.
$page_title = 'Login';




// Create the form.
?>
<link href="main.css" rel="stylesheet" type="text/css" />
<div id="nifty">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="0"><h1 id="mainhead">Guild Listing</h1></td>
    <td align="right" valign="top">
	
	<form action="guilds.php" method="post">
	<span class="subtitle">Registered Users:</span>
	<input name="username" type="text" value="Username" size="12" maxlength="40" />
	<input name="password" type="password" value="Password" size="12" maxlength="40" />
	<input type="submit" name="Submit" value="Login" />
	<input type="hidden" name="submitted" value="TRUE" />
</form>


<?php
//start GUILD LISTING
require_once('./config.php');

if (!empty($errors)) { // Print any error messages.
	echo "<span class='style1'>";
	foreach ($errors as $msg) { // Print each error.
		echo "$msg<br />\n";
	}
	echo "</span>";
}?>
	
      
	  <br /></td>
  </tr>
</table>
<?php
// Number of records to show per page:
$display = 15;

// Determine how many pages there are. 
if (isset($_GET['np'])) { // Already been determined.
	$num_pages = $_GET['np'];
} else { // Need to determine.

 	// Count the number of records
	$query = "SELECT COUNT(*) FROM guilds WHERE isAdmin='0' ORDER BY guildname ASC";
	$result = @mysql_query ($query);
	$row = mysql_fetch_array ($result, MYSQL_NUM);
	$num_records = $row[0];
	
	// Calculate the number of pages.
	if ($num_records > $display) { // More than 1 page.
		$num_pages = ceil ($num_records/$display);
	} else {
		$num_pages = 1;
	}
	
} // End of np IF.

// Determine where in the database to start returning results.
if (isset($_GET['s'])) {
	$start = $_GET['s'];
} else {
	$start = 0;
}

// Default column links.
$link1 = "{$_SERVER['PHP_SELF']}?sort=gna";
$link2 = "{$_SERVER['PHP_SELF']}?sort=gla";
$link3 = "{$_SERVER['PHP_SELF']}?sort=gwa";
$link4 = "{$_SERVER['PHP_SELF']}?sort=una";
$link5 = "{$_SERVER['PHP_SELF']}?sort=pta";
$link6 = "{$_SERVER['PHP_SELF']}?sort=faa";

// Determine the sorting order.
if (isset($_GET['sort'])) {

	// Use existing sorting order.
	switch ($_GET['sort']) {
		case 'gna':
			$order_by = 'guildname ASC';
			$link1 = "{$_SERVER['PHP_SELF']}?sort=gnd";
			break;
		case 'gnd':
			$order_by = 'guildname DESC';
			$link1 = "{$_SERVER['PHP_SELF']}?sort=gna";
			break;
		case 'gla':
			$order_by = 'guildlead ASC';
			$link2 = "{$_SERVER['PHP_SELF']}?sort=gld";
			break;
		case 'gld':
			$order_by = 'guildlead DESC';
			$link2 = "{$_SERVER['PHP_SELF']}?sort=gla";
			break;
		case 'gwa':
			$order_by = 'guildsite ASC';
			$link3 = "{$_SERVER['PHP_SELF']}?sort=gwd";
			break;
		case 'gwd':
			$order_by = 'guildsite DESC';
			$link3 = "{$_SERVER['PHP_SELF']}?sort=gwa";
			break;
		case 'una':
			$order_by = 'username ASC';
			$link4 = "{$_SERVER['PHP_SELF']}?sort=und";
			break;
		case 'und':
			$order_by = 'username DESC';
			$link4 = "{$_SERVER['PHP_SELF']}?sort=una";
			break;
		case 'pta':
			$order_by = 'points ASC';
			$link5 = "{$_SERVER['PHP_SELF']}?sort=ptd";
			break;
		case 'ptd':
			$order_by = 'points DESC';
			$link5 = "{$_SERVER['PHP_SELF']}?sort=pta";
			break;
		case 'faa':
			$order_by = 'faction ASC';
			$link6 = "{$_SERVER['PHP_SELF']}?sort=fad";
			break;
		case 'fad':
			$order_by = 'faction DESC';
			$link6 = "{$_SERVER['PHP_SELF']}?sort=faa";
			break;
		default:
			$order_by = 'guildname DESC';
			break;
	}
	
	// $sort will be appended to the pagination links.
	$sort = $_GET['sort'];
	
} else { // Use the default sorting order.
	$order_by = 'guildname ASC';
	$sort = 'gnd';
}
		
// Make the query.
$query = "SELECT guildname, guildlead, guildsite, username, points, userid, faction FROM guilds WHERE (isAdmin='0') ORDER BY $order_by LIMIT $start, $display";		
$result = @mysql_query ($query); // Run the query.

// Table header.
echo '<table cellspacing="0" cellpadding="5" width="90%" align="center">
<tr>
	<td align="left"><b><a href="' . $link1 . '">Guild Name</a></b></td>
	<td align="left"><b><a href="' . $link6 . '">Faction</a></b></td>
	<td align="left"><b><a href="' . $link2 . '">Guild Leader</a></b></td>
	<td align="left"><b><a href="' . $link3 . '">Guild Website</a></b></td>
	<td align="left"><b><a href="' . $link5 . '">Points</a></b></td>
</tr>
';

// Fetch and print all the records.
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$bg = '#eeeeee'; // Set the background color.
	if ($row['faction'] == 'horde') {
			$bg='#990000';
		} else {
			$bg='#0033CC';
		}
	echo '<tr bgcolor="' . $bg . '">
		<td align="left">' . $row['guildname'] . '</td>
		<td align="left">' . $row['faction'] . '</td>
		<td align="left">' . $row['guildlead'] . '</td>
		<td align="left">' . $row['guildsite'] . '</td>
		<td align="left">' . $row['points'] . '</td>
	</tr>
	';
}

echo '</table>';

mysql_free_result ($result); // Free up the resources.	

mysql_close(); // Close the database connection.

// Make the links to other pages, if necessary.
if ($num_pages > 1) {
	
	echo '<br /><p>';
	// Determine what page the script is on.	
	$current_page = ($start/$display) + 1;
	
	// If it's not the first page, make a Previous button.
	if ($current_page != 1) {
		echo '<a href="guilds.php?s=' . ($start - $display) . '&np=' . $num_pages . '&sort=' . $sort .'">Previous</a> ';
	}
	
	// Make all the numbered pages.
	for ($i = 1; $i <= $num_pages; $i++) {
		if ($i != $current_page) {
			echo '<a href="guilds.php?s=' . (($display * ($i - 1))) . '&np=' . $num_pages . '&sort=' . $sort .'">' . $i . '</a> ';
		} else {
			echo $i . ' ';
		}
	}
	
	// If it's not the last page, make a Next button.
	if ($current_page != $num_pages) {
		echo '<a href="guilds.php?s=' . ($start + $display) . '&np=' . $num_pages . '&sort=' . $sort .'">Next</a>';
	}
	
	echo '</p>';
	
} // End of links section.
?>
<b class="rbottom"><b class="r4"></b><b class="r3"></b><b class="r2"></b><b class="r1"></b></b></div>

</body>
</html>