<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Lightninghoof PvE Rankings</title>
<style type="text/css"> 	
body{
	padding: 20px;
	background-color: #000000;
	font: 11px "Trebuchet MS",Verdana,Arial,sans-serif;
	background-image: url(rankingbg.jpg);
	/**background:url(./images/<?= "gentlemansun".rand(1,8).".jpg"; ?>);**/
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
h1,h2,p{margin: 0 10px}
h1{font-size: 250%;color: #FFF}
h2{font-size: 200%;color: #f0f0f0}
.subtitle{font-size: 150%;color: #FFF}
p{padding-bottom:1em;color: #FFF}
h2{padding-top: 0.3em}
img{}
div#nifty{
	background: #000000;
	opacity:.80;
	width:90%;
	filter:alpha(opacity=80);
	margin-top: -20px;
	margin-right: 5%;
	margin-left: 5%;
}
img {
	text-align: center;
	margin: 5px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
div#nifty2{ 
	margin: 0 5%;
	background: #000000;
	width:90%;
}
b.rtop, b.rbottom{display:block;background: #461A3A}
b.rtop b, b.rbottom b{display:block;height: 1px;
    overflow: hidden; background: #000000}
b.r1{margin: 0 5px}
b.r2{margin: 0 3px}
b.r3{margin: 0 2px}
b.rtop b.r4, b.rbottom b.r4{margin: 0 1px;height: 2px}
body,td,th {
	font-size: 11px;
	color: #FFFFFF;
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
td:a:link {
	color: #FF9900;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FF9900;
}
a:hover {
	text-decoration: underline;
	color: #FF9900;
}
a:active {
	text-decoration: none;
	color: #FF9900;
}

a.info{
    position:relative; /*this is the key*/
    z-index:24; 
	/*background-color:#000;*/
    color:#FFF;
    text-decoration:none
	font-size: 50%
	}

a.info:hover{z-index:25; background-color:#FF9900}

a.info span{display: none}

a.info:hover span{ /*the span will display just on :hover state*/
    display:block;
    position:absolute;
    top:1em; left:0em; width:20em;
    border:1px solid #666;
    background-color:#FFF; color:#000;
    text-align: center}
.style1 {
	color: #FF3300 !important;
	font-size: 24px;
}
.centered {
	text-align: center;
}
.style2 {font-size: 24px}
</style>
</head>
<body>
<div id="nifty">
<b class="rtop"><b class="r3"></b></b>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="50%"><h1>How to get a Login.</h1></td>
    <td width="50%" align="right" valign="top" class="subtitle"><a href="index.php">Back to Home</a> </td>
  </tr>
</table>
<b class="rtop"><b class="r2"></b></b>
<p><b class="rtop"><b class="r4"></b></b><br />
  <span class="style1">This isn't very hard at all!</span><span class="style2"> To get a login for your guild to update your listings LIVE and attach screenshots, just contact moonmaster and let me know that you would like a login - if you are the guild leader on armory, i will give you your login so that you can update yourself!</span></p>
<p>How to contact Moonmaster:</p>
<p>Ingame: Moonmaster on Lightninghoof-Horde. Also, Moonah, Integrah.<br />
email: techotter at gmail dot com<br />
  msn: same as above<br />
      <br />
    you can also reach me at the Lightninghoof IRC: Just go to <a href="http://www.techotter.com/irc">http://www.techotter.com/irc</a>, and at the prompt, type &quot;/join lightninghoof&quot;. I should be in the room.<br />
</p>
</div>
</body>
</html>