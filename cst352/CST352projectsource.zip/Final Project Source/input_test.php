<html>
<body>

<?php
require_once("./config.php");

if (!isset($_POST['reset']))
{
	if (isset($_POST['submitted']))
	{
		$errormsg = "";

		//check name is blank
		if (empty($_POST['name']))
		{
			$name = NULL;
			$errormsg .="Please fill in the Guild Name.<br>";
		}
		else
		{
			$name = stripslashes($_POST['name']);
		} //end check name is blank
		
		//check leader is blank
		if (empty($_POST['leader']))
		{
			$leader = NULL;
			$errormsg .="Please fill in your Guild Leader.<br>";
		}
		else
		{
			$leader = stripslashes($_POST['leader']);
		} //end check leader is blank
		
		// Check if login is blank
		if (empty($_POST['login']))
		{
			$login = NULL;
			$errormsg .= "Please enter a username for your guild.";
		}
		else
		{
			$login = stripslashes($_POST['login']);
		} //end check login is blank
		
			// Check if password is same/blank
		if (empty($_POST['password'])) 
		{
			$password = NULL;
			$errormsg .= "Please enter a password.";
		} elseif($_POST['password'] != $_POST['password2']) {
				$errormsg .= "Your password confirmation did not match."; 
		} else {
			$password = stripslashes($_POST['password']);
		}
		} //end check password
		
		$website = stripslashes($_POST['website']);
		
		if ($errormsg!="") {
			echo $errormsg."<br>";
		}
		else 
		{
			$query = "INSERT INTO guilds (guildname, guildlead, guildsite, username, password) VALUES ('$name','$leader','$website','$login',SHA('$password'))";
			$result = @mysql_query ($query);
		}
	}
?>


Add Guilds
<form action="<?php $_SERVER['../rankings/PHP_SELF']?>" method="post">

<!--Disc Brand Field-->
<input name="name" type="text" value="<?php if(isset($_POST['reset'])) echo 'Guild Name';	elseif(isset($_POST['name']) ) echo $_POST['name'];  else echo 'Guild Name'; ?>" id="name" size="20" maxlength="60" />
<input name="leader" type="text" id="leader" value="<?php if(isset($_POST['reset'])) echo 'Guild Leader';	elseif (isset($_POST['leader'])) echo $_POST['leader'];  else echo 'Guild Leader'; ?>" size="20" maxlength="60" />
<input name="website" type="text" id="website" value="<?php if(isset($_POST['reset'])) echo 'Website';	elseif (isset($_POST['website'])) echo $_POST['website'];	else echo 'Website'; ?>" size="20" maxlength="60" />
<hr noshade width="400">  

<!--disc weight field-->
Username: 
<input name="login" type="text" value="<?php if(isset($_POST['reset'])) echo '';	elseif(isset($_POST['login']) ) echo $_POST['login']; else echo '';  ?>" id="url" size="20" maxlength="40" />
<!--Disc URL Field-->
Password: 
<input name="password" type="password" value="" id="url" size="20" maxlength="40" />
Confirm Password: 
<input name="password2" type="password" value="" id="url" size="20" maxlength="40" />
<br /><br />

  <!--buttons-->

    <input type="submit" name="Submit" value="Submit">

    <input name="reset" type="submit" id="Reset" value="Reset">

	<input type="hidden" name="submitted"  />

</form>

</body>
</html>