<?php
// This script displays then Thumbnail or Actual image
// Database connect
require_once '../../config.php';

// script has one REQUIRED parameter:  id, which is id of record containing the image
if (empty($_GET['id'])) die("No ID");

// script has one other parameter: imagekind:
//		either T for Thumbnail or P for photo, defaults to P
if (empty($_GET['imagekind'])) 
	$_GET['imagekind'] = 'P';
	
// select based on the type desired
if ($_GET['imagekind'] == 'P') {
	$query = 'select filedata,photowidth,photoheight,';
}
else {
	$query = 'select thumbdata as filedata,thumbwidth as photowidth,thumbheight as photoheight,';
}
$query .= 'filetype from kills where killid=' . $_GET['id'];
$result = mysql_query($query,$dblink) or die("Retrieve query failed: $query " . mysql_error());
$line = mysql_fetch_assoc($result) or die("Couldn't get record: $query");

header('Content-Type: ' . $line['filetype']);
header('Content-Disposition: inline; filename=' . $line['filename']);
// use "Content-Disposition: attachment" if you want the browser to prompt to save the file

//Display the image	
echo $line['filedata'];
?>