<html><link href="main.css" rel="stylesheet" type="text/css">
<div id="nifty">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="0"><h2 id="mainhead">
    <?php // Check for a valid user ID, through GET or POST.
if ( (isset($_GET['killid'])) && (is_numeric($_GET['killid'])) ) {
	$killid = $_GET['killid'];
	
require_once("./config.php");

$query = "SELECT guildid, bossid, dateentered FROM kills WHERE (killid='$killid')";
$result = mysql_query($query);
$num = mysql_num_rows($result);
if (mysql_num_rows($result) == 1) { // No Similar Entries
	$row = mysql_fetch_assoc($result);
}
$guildid = $row['guildid'];
$bossid = $row['bossid'];
$dateenetered = date('d m y', strtotime($row['dateentered']));


$query = "SELECT bossname, instancename FROM bosses WHERE (bossid='$bossid')";
$result = mysql_query($query);
$num = mysql_num_rows($result);
if (mysql_num_rows($result) == 1) { // No Similar Entries
	$row = mysql_fetch_assoc($result);
}

$bossname = $row['bossname'];
$instancename = $row['instancename'];


$query = "SELECT guildname FROM guilds WHERE (userid='$guildid')";
$result = mysql_query($query);
$num = mysql_num_rows($result);
if (mysql_num_rows($result) == 1) { // No Similar Entries
	$row = mysql_fetch_assoc($result);
}

$guildname = $row['guildname'];

} else { // No valid ID, kill the script.
	echo '<h1 id="mainhead">Page Error</h1>
	<p class="error">This page has been accessed in error.</p><p><br /><br /></p>';
	//exit();
}

?>
    Boss Kill: <?php echo $bossname; ?></h2><span class=style2>Located in <?php echo $instancename; ?></span><br /><span class=style2>Downed by <?php echo $guildname; ?>.</span><br /><span class=style2>Included in the<?php echo date('F n Y', strtotime($dateentered)); ?> update.</span></td>
    <td align="right" valign="top">
</td></tr></table><hr align=left width=250px noshade>
<div style="margin-left: 10px" align=center><?php echo '<img src=getfile.php?id=' . $killid . '&imagekind=P>'?></img></div>
<b class="rbottom"><b class="r4"></b><b class="r3"></b><b class="r2"></b><b class="r1"></b></b></div></html>

