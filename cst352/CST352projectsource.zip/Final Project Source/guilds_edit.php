<?php # User is redirected here from guilds.php.

session_start(); // Start the session.

// If no session value is present, redirect the user.
if (!isset($_SESSION['user_id'])) {

	// Start defining the URL.
	$url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
	// Check for a trailing slash.
	if ((substr($url, -1) == '/') OR (substr($url, -1) == '\\') ) {
		$url = substr ($url, 0, -1); // Chop off the slash.
	}
	$url .= '/guilds.php'; // Add the page.
	header("Location: $url");
	exit(); // Quit the script.
}

// Create the form.
?>
<link href="main.css" rel="stylesheet" type="text/css" />
<div id="nifty">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="0"><h1 id="mainhead">Guild Listing</h1></td>
    <td align="right" valign="top">
	
	<span class=subtitle> Welcome, <?php echo "{$_SESSION['user_id']}!"?> </span><span class="style1"><a href=guilds_logout.php>Logout.</a></span>
</td></tr></table>

<?php
require_once('./config.php');
//INPUT FORM START
if (!isset($_POST['reset']))
{
	if (isset($_POST['submitted']))
	{
		$errormsg = "";

		//check name is blank
		if (empty($_POST['name']))
		{
			$name = NULL;
			$errormsg .="Please fill in the Guild Name.<br>";
		}
		else
		{
			$name = stripslashes($_POST['name']);
		} //end check name is blank
		
		//check leader is blank
		if (empty($_POST['leader']))
		{
			$leader = NULL;
			$errormsg .="Please fill in your Guild Leader.<br>";
		}
		else
		{
			$leader = stripslashes($_POST['leader']);
		} //end check leader is blank
		
		// Check if login is blank
		if (empty($_POST['login']))
		{
			$login = NULL;
			$errormsg .= "Please enter a username for your guild.";
		}
		else
		{
			$login = stripslashes($_POST['login']);
		} //end check login is blank
		
			// Check if password is same/blank
		if (empty($_POST['password'])) 
		{
			$password = NULL;
			$errormsg .= "Please enter a password.";
		} elseif($_POST['password'] != $_POST['password2']) {
				$errormsg .= "Your password confirmation did not match."; 
		} else {
			$password = stripslashes($_POST['password']);
		}
		} //end check password
		
		$website = stripslashes($_POST['website']);
		$faction = stripslashes($_POST['faction']);
		
		if ($errormsg!="") {
			echo $errormsg."<br>";
		}
		elseif (isset($_POST['submitted']))
		{
			$query = "INSERT INTO guilds (guildname, faction, guildlead, guildsite, username, password) VALUES ('$name','$faction','$leader','$website','$login',SHA('$password'))";
			$result = @mysql_query ($query);
		}
	}
?>
<div align=center><form action="<?php $_SERVER['../rankings/PHP_SELF']?>" method="post">

<!--Disc Brand Field-->
<input name="name" type="text" value="<?php if(isset($_POST['reset'])) echo 'Guild Name';	elseif(isset($_POST['name']) ) echo $_POST['name'];  else echo 'Guild Name'; ?>" id="name" size="20" maxlength="60" />&nbsp;&nbsp;
<input name="leader" type="text" id="leader" value="<?php if(isset($_POST['reset'])) echo 'Guild Leader';	elseif (isset($_POST['leader'])) echo $_POST['leader'];  else echo 'Guild Leader'; ?>" size="20" maxlength="60" />&nbsp;&nbsp;
<input name="website" type="text" id="website" value="<?php if(isset($_POST['reset'])) echo 'Website';	elseif (isset($_POST['website'])) echo $_POST['website'];	else echo 'Website'; ?>" size="20" maxlength="60" />&nbsp;&nbsp;
<select name="faction">
  <option value="horde">Horde</option>
  <option value="alliance">Alliance</option>
</select>
<hr noshade width="400">  

<!--disc weight field-->
Username: 
<input name="login" type="text" value="<?php if(isset($_POST['reset'])) echo '';	elseif(isset($_POST['login']) ) echo $_POST['login']; else echo '';  ?>" id="url" size="20" maxlength="40" />
<!--Disc URL Field-->
Password: 
<input name="password" type="password" value="" id="url" size="20" maxlength="40" />
Confirm Password: 
<input name="password2" type="password" value="" id="url" size="20" maxlength="40" />
<br /><br />

  <!--buttons-->

    <input type="submit" name="Submit" value="Submit">

    <input name="reset" type="submit" id="Reset" value="Reset">

	<input type="hidden" name="submitted" value="true" />

</form></div><div id="form">

<?php
//start GUILD LISTING
require_once('./config.php');

if (!empty($errors)) { // Print any error messages.
	echo "<span class='style1'>";
	foreach ($errors as $msg) { // Print each error.
		echo "$msg<br />\n";
	}
	echo "</span>";
}?>
	
      
	  <br /></td>
  </tr>
</table>
<?php
// Number of records to show per page:
$display = 15;

// Determine how many pages there are. 
if (isset($_GET['np'])) { // Already been determined.
	$num_pages = $_GET['np'];
} else { // Need to determine.

 	// Count the number of records
	$query = "SELECT COUNT(*) FROM guilds WHERE isAdmin='0' ORDER BY guildname ASC";
	$result = @mysql_query ($query);
	$row = mysql_fetch_array ($result, MYSQL_NUM);
	$num_records = $row[0];
	
	// Calculate the number of pages.
	if ($num_records > $display) { // More than 1 page.
		$num_pages = ceil ($num_records/$display);
	} else {
		$num_pages = 1;
	}
	
} // End of np IF.

// Determine where in the database to start returning results.
if (isset($_GET['s'])) {
	$start = $_GET['s'];
} else {
	$start = 0;
}

// Default column links.
$link1 = "{$_SERVER['PHP_SELF']}?sort=gna";
$link2 = "{$_SERVER['PHP_SELF']}?sort=gla";
$link3 = "{$_SERVER['PHP_SELF']}?sort=gwa";
$link4 = "{$_SERVER['PHP_SELF']}?sort=una";
$link5 = "{$_SERVER['PHP_SELF']}?sort=pta";
$link6 = "{$_SERVER['PHP_SELF']}?sort=faa";

// Determine the sorting order.
if (isset($_GET['sort'])) {

	// Use existing sorting order.
	switch ($_GET['sort']) {
		case 'gna':
			$order_by = 'guildname ASC';
			$link1 = "{$_SERVER['PHP_SELF']}?sort=gnd";
			break;
		case 'gnd':
			$order_by = 'guildname DESC';
			$link1 = "{$_SERVER['PHP_SELF']}?sort=gna";
			break;
		case 'gla':
			$order_by = 'guildlead ASC';
			$link2 = "{$_SERVER['PHP_SELF']}?sort=gld";
			break;
		case 'gld':
			$order_by = 'guildlead DESC';
			$link2 = "{$_SERVER['PHP_SELF']}?sort=gla";
			break;
		case 'gwa':
			$order_by = 'guildsite ASC';
			$link3 = "{$_SERVER['PHP_SELF']}?sort=gwd";
			break;
		case 'gwd':
			$order_by = 'guildsite DESC';
			$link3 = "{$_SERVER['PHP_SELF']}?sort=gwa";
			break;
		case 'una':
			$order_by = 'username ASC';
			$link4 = "{$_SERVER['PHP_SELF']}?sort=und";
			break;
		case 'und':
			$order_by = 'username DESC';
			$link4 = "{$_SERVER['PHP_SELF']}?sort=una";
			break;
		case 'pta':
			$order_by = 'points ASC';
			$link5 = "{$_SERVER['PHP_SELF']}?sort=ptd";
			break;
		case 'ptd':
			$order_by = 'points DESC';
			$link5 = "{$_SERVER['PHP_SELF']}?sort=pta";
			break;
		case 'faa':
			$order_by = 'faction ASC';
			$link6 = "{$_SERVER['PHP_SELF']}?sort=fad";
			break;
		case 'fad':
			$order_by = 'faction DESC';
			$link6 = "{$_SERVER['PHP_SELF']}?sort=faa";
			break;
		default:
			$order_by = 'guildname DESC';
			break;
	}
	
	// $sort will be appended to the pagination links.
	$sort = $_GET['sort'];
	
} else { // Use the default sorting order.
	$order_by = 'guildname ASC';
	$sort = 'gnd';
}
		
// Make the query.
$query = "SELECT guildname, guildlead, guildsite, username, points, userid, faction FROM guilds WHERE (isAdmin='0') ORDER BY $order_by LIMIT $start, $display";		
$result = @mysql_query ($query); // Run the query.

// Table header.
echo '<table cellspacing="0" cellpadding="5" width="95%" align="center">
<tr>
	<td align="right"><b>Edit</b></td>
	<td align="left"><b>Delete</b></td>
	<td align="left"><b><a href="' . $link1 . '">Guild Name</a></b></td>
	<td align="left"><b><a href="' . $link6 . '">Faction</a></b></td>
	<td align="left"><b><a href="' . $link2 . '">Guild Leader</a></b></td>
	<td align="left"><b><a href="' . $link3 . '">Guild Website</a></b></td>
	<td align="left"><b><a href="' . $link4 . '">username</a></b></td>
	<td align="left"><b><a href="' . $link5 . '">Points</a></b></td>
</tr>
';

// Fetch and print all the records.
$bg = '#eeeeee'; // Set the background color.
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$bg = '#eeeeee'; // Set the background color.
	if ($row['faction'] == 'horde') {
			$bg='#990000';
		} else {
			$bg='#0033CC';
		}
	echo '<tr bgcolor="' . $bg . '">
		<td align="right"><a href="edit_guild.php?id=' . $row['discID'] . '">Edit</a></td>
		<td align="left"><a href="delete_guild.php?id=' . $row['discID'] . '">Delete</a></td>
		<td align="left">' . $row['guildname'] . '</td>
		<td align="left">' . $row['faction'] . '</td>
		<td align="left">' . $row['guildlead'] . '</td>
		<td align="left">' . $row['guildsite'] . '</td>
		<td align="left">' . $row['username'] . '</td>
		<td align="left">' . $row['points'] . '</td>
	</tr>
	';
}

echo '</table>';

mysql_free_result ($result); // Free up the resources.	

mysql_close(); // Close the database connection.

// Make the links to other pages, if necessary.
if ($num_pages > 1) {
	
	echo '<br /><p>';
	// Determine what page the script is on.	
	$current_page = ($start/$display) + 1;
	
	// If it's not the first page, make a Previous button.
	if ($current_page != 1) {
		echo '<a href="guilds_edit.php?s=' . ($start - $display) . '&np=' . $num_pages . '&sort=' . $sort .'">Previous</a> ';
	}
	
	// Make all the numbered pages.
	for ($i = 1; $i <= $num_pages; $i++) {
		if ($i != $current_page) {
			echo '<a href="guilds_edit.php?s=' . (($display * ($i - 1))) . '&np=' . $num_pages . '&sort=' . $sort .'">' . $i . '</a> ';
		} else {
			echo $i . ' ';
		}
	}
	
	// If it's not the last page, make a Next button.
	if ($current_page != $num_pages) {
		echo '<a href="guilds_edit.php?s=' . ($start + $display) . '&np=' . $num_pages . '&sort=' . $sort .'">Next</a>';
	}
	
	echo '</p>';
	
} // End of links section.
?>
<b class="rbottom"><b class="r4"></b><b class="r3"></b><b class="r2"></b><b class="r1"></b></b></div>

</body>
</html>