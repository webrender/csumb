<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Lightninghoof PvE Rankings</title>
<style type="text/css"> 	
body{
	background-color: #000000;
	font: 11px "Trebuchet MS",Verdana,Arial,sans-serif;
	background-image: url(rankingbg.jpg);
	margin: 0px;
	padding-top: 0px;
	padding-right: 20px;
	padding-bottom: 20px;
	padding-left: 20px;
}
h1,h2,p{margin: 0 10px}
h1{font-size: 250%;color: #FFF}
h2{font-size: 200%;color: #f0f0f0}
.subtitle{font-size: 150%;color: #FFF}
p{padding-bottom:1em;color: #FFF}
h2{padding-top: 0.3em}
img{}
div#nifty{
	background: #000000;
	opacity:.80;
	width:90%;
	filter:alpha(opacity=80);
	margin-top: 0px;
	margin-right: 5%;
	margin-bottom: 0;
	margin-left: 5%;
}
img {
	text-align: center;
	margin: 5px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
div#nifty2{ 
	margin: 0 5%;
	background: #000000;
	width:90%;
}
b.rtop, b.rbottom{display:block;background: #461A3A}
b.rtop b, b.rbottom b{display:block;height: 1px;
    overflow: hidden; background: #000000}
b.r1{margin: 0 5px}
b.r2{margin: 0 3px}
b.r3{margin: 0 2px}
b.rtop b.r4, b.rbottom b.r4{margin: 0 1px;height: 2px}
body,td,th {
	font-size: 11px;
	color: #FFFFFF;
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
td:a:link {
	color: #FF9900;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FF9900;
}
a:hover {
	text-decoration: underline;
	color: #FF9900;
}
a:active {
	text-decoration: none;
	color: #FF9900;
}

a.info{
    position:relative; /*this is the key*/
    z-index:24; 
	/*background-color:#000;*/
    color:#FFF;
    text-decoration:none
	font-size: 50%
	}

a.info:hover{z-index:25; background-color:#FF9900}

a.info span{display: none}

a.info:hover span{ /*the span will display just on :hover state*/
    display:block;
    position:absolute;
    top:1em; left:0em; width:20em;
    border:1px solid #666;
    background-color:#FFF; color:#000;
    text-align: center}
.style1 {color: #FF3300 !important}
.centered {
	text-align: center;
}
</style>
</head>
<body>
<div id="nifty">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="0"></td>
    <td align="right" valign="top"><span class="subtitle">Administrators:</span>
      <input name="textfield" type="text" value="Username" size="12" maxlength="40" />
	  <input name="password" type="text" value="Password" size="12" maxlength="40" />
	  <input type="submit" name="Submit" value="Login" />
	  <br /></td>
  </tr>
</table>
<?php 
$page_title = 'Guild Listing';

// Page header.
echo '<h1 id="mainhead">Guild Listing</h1>';

require_once("./config.php"); // Connect to the db.

// Number of records to show per page:
$display = 20;

// Determine how many pages there are. 
if (isset($_GET['np'])) { // Already been determined.
	$num_pages = $_GET['np'];
} else { // Need to determine.

 	// Count the number of records
	$query = "SELECT COUNT(*) FROM discs ORDER BY discName ASC";
	$result = @mysql_query ($query);
	$row = mysql_fetch_array ($result, MYSQL_NUM);
	$num_records = $row[0];
	
	// Calculate the number of pages.
	if ($num_records > $display) { // More than 1 page.
		$num_pages = ceil ($num_records/$display);
	} else {
		$num_pages = 1;
	}
	
} // End of np IF.

// Determine where in the database to start returning results.
if (isset($_GET['s'])) {
	$start = $_GET['s'];
} else {
	$start = 0;
}

// Default column links.
$link1 = "{$_SERVER['PHP_SELF']}?sort=nma";
$link2 = "{$_SERVER['PHP_SELF']}?sort=bra";
$link3 = "{$_SERVER['PHP_SELF']}?sort=wea";

// Determine the sorting order.
if (isset($_GET['sort'])) {

	// Use existing sorting order.
	switch ($_GET['sort']) {
		case 'nma':
			$order_by = 'discName ASC';
			$link1 = "{$_SERVER['PHP_SELF']}?sort=nmd";
			break;
		case 'nmd':
			$order_by = 'discName DESC';
			$link1 = "{$_SERVER['PHP_SELF']}?sort=nma";
			break;
		case 'bra':
			$order_by = 'discBrand ASC';
			$link2 = "{$_SERVER['PHP_SELF']}?sort=brd";
			break;
		case 'brd':
			$order_by = 'discBrand DESC';
			$link2 = "{$_SERVER['PHP_SELF']}?sort=bra";
			break;
		case 'wea':
			$order_by = 'discWeight ASC';
			$link3 = "{$_SERVER['PHP_SELF']}?sort=wed";
			break;
		case 'wed':
			$order_by = 'discWeight DESC';
			$link3 = "{$_SERVER['PHP_SELF']}?sort=wea";
			break;
		default:
			$order_by = 'discName DESC';
			break;
	}
	
	// $sort will be appended to the pagination links.
	$sort = $_GET['sort'];
	
} else { // Use the default sorting order.
	$order_by = 'discName ASC';
	$sort = 'drd';
}
		
// Make the query.
$query = "SELECT discName, discBrand, discWeight, discID FROM discs ORDER BY $order_by LIMIT $start, $display";		
$result = @mysql_query ($query); // Run the query.

// Table header.
echo '<table align="left" cellspacing="0" cellpadding="5" width="100%">
<tr>
	<td align="left" width="20%"><b><a href="' . $link1 . '">Guild Name</a></b></td>
	<td align="left" width="20%"><b><a href="' . $link2 . '">Disc Brand</a></b></td>
	<td align="left" width="40%"><b><a href="' . $link3 . '">Disc Weight</a></b></td>
</tr>
';

// Fetch and print all the records.
$bg = '#eeeeee'; // Set the background color.
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$bg = ($bg=='#666666' ? '#333333' : '#666666'); // Switch the background color.
	echo '<tr bgcolor="' . $bg . '">
		<td align="left"><a href="9b-laskar.php?id=' . $row['discID'] . '">Edit</a></td>
		<td align="left"><a href="delete_user.php?id=' . $row['discID'] . '">Delete</a></td>
		<td align="left">' . $row['discName'] . '</td>
		<td align="left">' . $row['discBrand'] . '</td>
		<td align="left">' . $row['discWeight'] . '</td>
	</tr>
	';
}

echo '</table>';

mysql_free_result ($result); // Free up the resources.	

mysql_close(); // Close the database connection.

// Make the links to other pages, if necessary.
if ($num_pages > 1) {
	
	echo '<br /><p>';
	// Determine what page the script is on.	
	$current_page = ($start/$display) + 1;
	
	// If it's not the first page, make a Previous button.
	if ($current_page != 1) {
		echo '<a href="guilds.php?s=' . ($start - $display) . '&np=' . $num_pages . '&sort=' . $sort .'">Previous</a> ';
	}
	
	// Make all the numbered pages.
	for ($i = 1; $i <= $num_pages; $i++) {
		if ($i != $current_page) {
			echo '<a href="guilds.php?s=' . (($display * ($i - 1))) . '&np=' . $num_pages . '&sort=' . $sort .'">' . $i . '</a> ';
		} else {
			echo $i . ' ';
		}
	}
	
	// If it's not the last page, make a Next button.
	if ($current_page != $num_pages) {
		echo '<a href="guilds.php?s=' . ($start + $display) . '&np=' . $num_pages . '&sort=' . $sort .'">Next</a>';
	}
	
	echo '</p>';
	
} // End of links section.
?>
<b class="rbottom"><b class="r4"></b><b class="r3"></b><b class="r2"></b><b class="r1"></b></b>
</div>
</body>
</html>
