<?php
session_start(); // Start the session.

// If no session value is present, redirect the user.
if (!isset($_SESSION['user_id'])) {
	// Start defining the URL.
	$url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
	// Check for a trailing slash.
	if ((substr($url, -1) == '/') OR (substr($url, -1) == '\\') ) {
		$url = substr ($url, 0, -1); // Chop off the slash.
	}
	$url .= '/notallowed.php'; // Add the page.
	header("Location: $url");
	exit(); // Quit the script.
}
require_once("./config.php"); // Connect to the db.
function escape_data ($data) {
	global $dblink; // Need the connection.
	if (ini_get('magic_quotes_gpc')) {
		$data = stripslashes($data);
	}
	return mysql_real_escape_string(trim($data), $dblink);
}

// Set the page title and include the HTML header.
$page_title = 'Update Boss Status';

// Check for a valid user ID, through GET or POST.
if ( (isset($_GET['bossid'])) && (is_numeric($_GET['bossid'])) ) {
	$bossid = $_GET['bossid'];
} elseif ( (isset($_POST['bossid'])) && (is_numeric($_POST['bossid'])) ) {
	$bossid = $_POST['bossid'];
} else { // No valid ID, kill the script.
	echo '<h1 id="mainhead">Page Error</h1>
	<p class="error">This page has been accessed in error.</p><p><br /><br /></p>';
	//exit();
}



$query = "SELECT bossname, instancename, bossorder, points FROM bosses WHERE (bossid='$bossid')";
$result = mysql_query($query);
$num = mysql_num_rows($result);
if (mysql_num_rows($result) == 1) { // No Similar Entries
	$row = mysql_fetch_assoc($result);
}
$currentdate = getdate();
$bosspoints = $row["points"];
echo '<link href="main.css" rel="stylesheet" type="text/css">
<div id="nifty">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="0"><h2 id="mainhead">Update Boss: ' . $row["bossname"] .'</h2><span class=style2>Boss #' . $row["bossorder"] . ' in the ' . $row["instancename"] .' instance.</span><br><span class=style2>Worth ' . $row["points"] . ' points.</span></td>
    <td align="right" valign="top">
</td></tr></table><hr align=left width=250px noshade>
<div style="margin-left: 10px">';
$userid = $_GET['userid'];
$query = "SELECT guildname, userid, points FROM guilds WHERE (userid='$userid')";
$result = mysql_query($query);
$num = mysql_num_rows($result);
if (mysql_num_rows($result) == 1) { // No Similar Entries
	$row = mysql_fetch_assoc($result);
}

/////////////////////////////////////////////////////
///////////BEGINNING OF IMAGE UPLOAD CODE////////////
/////////////////////////////////////////////////////

if (isset($_POST['submitted'])) {
if (isset($_FILES)) {
	echo '<PRE>';
	//print_r($_FILES);
	echo '</PRE>';

	// Define the sizes of the two images.  
	// Large image is constrained to maximum of BIGMAX on either dimension
	// Thumbnail is constrained so that larger 
	define('BIGMAX',600);		// large image is no larger than 600 x 600
	define('THUMBMAX',100);		// thumbnail is no larger than 150 x 150

	// if we've got a file and it's valid
	if (isset($_FILES['userfile']) && is_uploaded_file($_FILES['userfile']['tmp_name'])) {

		// save the filename for use later
		$filename = $_FILES['userfile']['name'];
		
		// BIG IMAGE section
		
		// first, get the size
		$imageinfo = getimagesize($_FILES['userfile']["tmp_name"]);
		//	0 width
		//	1 height
		//	2 type
		switch ($imageinfo[2]) {	// create the image based on its type -- see MIME type constants above
		case 1:	// GIF
	  	    $sourcefile = imagecreatefromgif ($_FILES['userfile']["tmp_name"]);
			break;
		case 2:	// JPG
	  	    $sourcefile = imagecreatefromjpeg ($_FILES['userfile']["tmp_name"]);
			break;
		case 3:	// PNG
	  	    $sourcefile = imagecreatefrompng ($_FILES['userfile']["tmp_name"]);
			break;
		}

		// if the image is already smaller in both dimensions than our maximum,
		// then our "big" version of the image is the same as our source
		if (($imageinfo[0] <= BIGMAX) && ($imageinfo[1] <= BIGMAX)) {
			$bigfile = $sourcefile;
		}			
		else {
			// otherwise we need to shrink it down to constrain it to no more
			// than BIGMAX x BIGMAX
			//echo 'BIGMAX: ' . BIGMAX . '<P>';	// *** debug
			//echo 'X: ' . imagesx($sourcefile) . ', Y: ' . imagesy($sourcefile) . '<P>'; // *** debug

			// See if we are more Landscape or Portrait orientation
			// See if width is > height -- this is Landscape
			if ($imageinfo[0] > $imageinfo[1]) {
				//echo 'Landscape<P>';			// *** debug
				// set the X size to be our maximum, and the Y size to correspond
				// based on the aspect ratio of the source image
			  	$newx = BIGMAX;
			  	$newy = round(BIGMAX/imagesx($sourcefile)*imagesy($sourcefile));
			  	//echo "($newx,$newy)<P>";		// *** debug
			}
			else {
				//echo 'Portrait<P>';				// *** debug
				// set the Y size to be our maximum, and the X size to correspond
				// based on the aspect ratio of the source image
				$newx = round(BIGMAX/imagesy($sourcefile)*imagesx($sourcefile));
				$newy = BIGMAX;
			  	//echo "($newx,$newy)<P>";		// *** debug
			}
			//echo 'About to create truecolor image....';	// *** debug
			// create new "big" image to copy into
			$bigfile = imagecreatetruecolor($newx,$newy);
			//echo 'created, now about to resample...';	// *** debug
			// copy into it, doing whatever shrinking is needed
			imagecopyresampled ($bigfile, $sourcefile, 0,0, 0,0, $newx, $newy, 
				 imagesx($sourcefile), imagesy($sourcefile)); 
			//echo 'resampled.<BR>';						// *** debug
		}
		
		// We want to create the output file (as a JPEG), but the built-in functions
		// will only do so, outputting either to a file or to the browser.  So we
		// turn on Output Buffering, capture the output in the buffer, and then
		// save it in a variable so we can later stuff it into an SQL query.
		
		// echo 'About to turn on buffering...needed because imagejpeg function displays the image';	// *** debug
		ob_start();					// turn on buffering
		// echo 'About to create JPEG....';		// *** debug, AND WILL SCREW UP THE OUTPUT
		imagejpeg($bigfile);		// output the JPEG
		// echo 'About to retrieve data...';	// *** debug, AND WILL SCREW UP THE OUTPUT if allowed to echo
		$filedata = ob_get_clean();	// retrieve the data and turn off buffering
		// Previous line gets data from buffer, stores contents in $filedata and then wipes buffer
		// echo 'Data retrieved: ' . $filedata;	// *** debug
		
		// normally, the file type is uploaded, but we're going to explicitly
		// specify that it's a JPEG.
		$filetype = 'image/jpeg';
		$filesize = strlen($filedata);		// set the length -- this is the size of the file
		$photowidth = imagesx($bigfile);	// save the width
		$photoheight = imagesy($bigfile);	// save the height
		
		//echo "<B>Photo created successfully.</B> ($photowidth, $photoheight)<BR>";

		// THUMBNAIL section
		// Same routine as above, just using THUMBMAX for the constraint
		// and we assume the uploaded file is always bigger than a thumbnail
        if (imagesx($sourcefile) > imagesy($sourcefile)) {
		  // x dimension is bigger than y
		  // scale x dimension to a percentage of THUMBMAX that will maintain aspect ratio
          $newy = round(THUMBMAX/imagesx($sourcefile)*imagesy($sourcefile));
          $newx = THUMBMAX;
        }
        else {
		  // y dimension is bigger than x
		  // scale y dimension to a percentage of THUMBMAX that will maintain aspect ratio
          $newy = round(THUMBMAX/imagesy($sourcefile)*imagesx($sourcefile));
          $newy = THUMBMAX;
        }
		// Create a blank image with the correct dimensions
        $thumb = imagecreatetruecolor($newx,$newy);
		// Sample the original image into $thumb scaled correctly
        imagecopyresampled ($thumb, $sourcefile, 0,0, 0,0, $newx, $newy, 
	         imagesx($sourcefile), imagesy($sourcefile)); 
		// Turn on buffering
		ob_start();
		// Display image (capstured in buffer)
		imagejpeg($thumb);
		// Save image and wipe buffer
		$thumbdata = ob_get_clean();
		$thumbwidth = $newx;		// save the thumbnail width for insert query
		$thumbheight = $newy;		// save the thumnail height for insert query
				
		//echo "<B>Thumbnail created successfully.</B> ($newx,$newy)<BR>";
	
		$guildid = $row['userid'];
		$newpoints = $row['points'] + $bosspoints;	
			
		// create the Insert query
		$query = "insert into kills (filename,filetype,filesize,filedata,
			photowidth,photoheight,thumbdata,thumbwidth,thumbheight,guildid,bossid) values 
		   ('$filename','$filetype',$filesize,'" .
			mysql_real_escape_string($filedata) .
			"',$photowidth,$photoheight,'" .
			mysql_real_escape_string($thumbdata) .
			"',$thumbwidth,$thumbheight,$guildid,$bossid)";
		mysql_query($query,$dblink) or die("File insert query failed: $query " . mysql_error());
		echo "<span class=style1>Image Uploaded. </span>";
		$query = "UPDATE guilds SET points='$newpoints' WHERE userid=$userid";
		mysql_query($query,$dblink) or die("File insert query failed: $query " . mysql_error());
		echo "Guild Status Updated.";
		echo "<br><a href=# onclick='window.close()'>Click here to close this window.</a>";
		echo "<script>window.opener.location.reload();window.close();</script>";
} else {
	echo "<span class=style1>You did not provide an image.  Your guild's status was still updated.</span>";
	$query = "insert into kills (guildid,bossid) values ($userid,$bossid)";
		mysql_query($query,$dblink) or die("File insert query failed: $query " . mysql_error());
	echo $userid;
	echo $bossid;
	echo "<script>window.opener.location.reload();</script>";
	$newpoints = $row['points'] + $bosspoints;		
	$query = "UPDATE guilds SET points='$newpoints' WHERE userid=$userid";
	mysql_query($query,$dblink) or die("File insert query failed: $query " . mysql_error());
	echo "<script>window.opener.location.reload();window.close();</script>";
}
}
// this could also have been:
/*	$query = "update uploadedfiles 
	set filename='$filename',
	    filetype='$filetype',
		filesize=$filesize,
		filedata='" . 
			mysql_real_escape_string($filedata) .
			"',
		photowidth=$photowidth,
		photoheight=$photoheight,
		thumbdata='" .
			mysql_real_escape_string($thumbdata) .
			"',
		thumbwidth=$thumbwidth,
		thumbheight=$thumbheight
			where id=" . $_POST['id'];			

*/		//$query = "insert into guilds (points) values ('$points')";
		//mysql_query($query,$dblink) or die("File insert query failed: $query " . mysql_error());
		
		// echo $query . '<P>';
		//echo "File $filename with type $filetype and size $filesize has been uploaded.<p>";
	// Update Guild Points
}


/////////////////////////////////////////////////////
////////////END OF IMAGE UPLOAD CODE/////////////////
/////////////////////////////////////////////////////
?>

<form action="<?php $_SERVER['../rankings/PHP_SELF']?>" method="post" enctype="multipart/form-data">
<input type ="hidden" name="MAX_FILE_SIZE" value=10000000>
<input  disabled="disabled" name="name" type="text" value="<?php echo $row['guildname']?>" id="name" size="20" maxlength="60" /><br />

<?php 
// Make the months array.
$months = array (1 => 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');

// Make the days and years arrays.
$days = range (1, 31);
$years = range (2005, 2015);

// Make the months pull-down menu.
echo '<select name="month">';
foreach ($months as $key => $value) {
	echo "<option value=\"$key\"";
	if ($currentdate['mon'] == $key) {
		echo "selected=\"selected\"";
	} else {echo "";}
	echo ">$value</option>\n";
}
echo '</select>';

// Make the days pull-down menu.
echo '<select name="day">';
foreach ($days as $value) {
	echo "<option value=\"$value\"";
	if ($currentdate['mday'] == $value) {
		echo "selected=\"selected\"";
	} else {echo "";}
	echo ">$value</option>\n";
}
echo '</select>';

// Make the years pull-down menu.
echo '<select name="year">';
foreach ($years as $value) {
	echo "<option value=\"$value\"";
	if ($currentdate['year'] == $value) {
		echo "selected=\"selected\"";
	} else {echo "";}
	echo ">$value</option>\n";
}
echo '</select>';

?><br />
<input type="file" name="userfile"><br><br>


  <!--buttons-->

    <input type="submit" name="Submit" value="Submit">

    <input name="reset" type="submit" id="Reset" value="Reset">

	<input type="hidden" name="submitted" value="true" />

</form></div>
<b class="rbottom"><b class="r4"></b><b class="r3"></b><b class="r2"></b><b class="r1"></b></b></div>


