<?php
session_start(); // Start the session.

// If no session value is present, redirect the user.
if (!isset($_SESSION['user_id'])) {
	// Start defining the URL.
	$url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
	// Check for a trailing slash.
	if ((substr($url, -1) == '/') OR (substr($url, -1) == '\\') ) {
		$url = substr ($url, 0, -1); // Chop off the slash.
	}
	$url .= '/notallowed.php'; // Add the page.
	header("Location: $url");
	exit(); // Quit the script.
}
require_once("./config.php"); // Connect to the db.
if (isset($_POST['submitted'])) {

	function escape_data ($data) {
		global $dblink; // Need the connection.
		if (ini_get('magic_quotes_gpc')) {
			$data = stripslashes($data);
		}
		return mysql_real_escape_string(trim($data), $dblink);
	}
	
	// Set the page title and include the HTML header.
	$page_title = 'Update Guild';
	$sessuserid = $_SESSION['user_id'];
	
	// Check for a valid user ID, through GET or POST.
	if ( (isset($_GET['bossid'])) && (is_numeric($_GET['bossid'])) ) {
		$bossid = $_GET['bossid'];
	} elseif ( (isset($_POST['submitted'])) ) {
		$bossid = $_POST['bossid'];
	} else { // No valid ID, kill the script.
		echo '<h1 id="mainhead">Page Error</h1>
		<p class="error">This page has been accessed in error!</p><p><br /><br /></p>';
		//exit();
	}

	$errors = array(); // Initialize error array.
	
	$website = escape_data($_POST['website']);
	
	// Check for an guild leader.
	if (empty($_POST['leader'])) {
		$errors[] = 'You forgot to enter a Guild Leader.';
	} else {
		$lead = escape_data($_POST['leader']);
	}
	
	// Check for a password and match against the confirmed password.
	if (!empty($_POST['password1'])) {
		$changepass = "yes";
		if ($_POST['password1'] != $_POST['password2']) {
			$errors[] = 'Your new password did not match the confirmed new password.';
		} else {
			$np = escape_data($_POST['password1']);
		}
	}
	if (empty($_POST['password1'])) {
		$changepass = "no";
	}
	
	if (empty($errors)) { // If everything's OK.
	
		// Check that they've entered the right email address/password combination.
		$query = "SELECT userid FROM guilds WHERE (username='$sessuserid')";
		$result = mysql_query($query);
		$num = mysql_num_rows($result);
		if (mysql_num_rows($result) == 1) { // Match was made.
		
			// Get the user_id.
			$row = mysql_fetch_array($result, MYSQL_NUM);

			// Make the UPDATE query.
			if ($changepass=="yes") {
				$query = "UPDATE guilds SET guildlead='$lead', guildsite='$website', password=SHA('$np') WHERE userid=$row[0]";	
			} else {
				$query = "UPDATE guilds SET guildlead='$lead', guildsite='$website' WHERE userid=$row[0]";	
			}
			$result = @mysql_query ($query);
			if (mysql_affected_rows() == 1) { // If it ran OK.
			
				// Send an email, if desired.
				
				// Print a message.
				echo '<h1 id="mainhead">Thank you!</h1><p>Your password has been updated.</p><p><br /></p>';
				echo $changepass;
				echo "<script>window.opener.location.reload();window.close();</script>";
				exit();
				
			} else { // If it did not run OK.
				echo '<h1 id="mainhead">System Error</h1>
				<p class="error">Your password could not be changed due to a system error. We apologize for any inconvenience.</p>'; // Public message.
				echo $dblink;
				echo '<p>' . mysql_error() . '<br /><br />Query: ' . $query . '</p>'; // Debugging message.
				exit();
			}
				
		} else { // Invalid email address/password combination.
			echo '<h1 id="mainhead">Error!</h1>
			<p class="error">The email address and password do not match those on file.</p>';
		}
		
	} else { // Report the errors.
	
		echo '<p class="error">The following error(s) occurred:<br />';
		foreach ($errors as $msg) { // Print each error.
			echo " - $msg<br />\n</p>";
		}
		
	} // End of if (empty($errors)) IF.

}	
 // End of the main Submit conditional.
$sessuserid = $_SESSION['user_id'];
$query = "SELECT guildname, password, guildlead, guildsite FROM guilds WHERE (username='$sessuserid')";
$result = mysql_query($query);
$num = mysql_num_rows($result);
if (mysql_num_rows($result) == 1) { // No Similar Entries
	$row = mysql_fetch_assoc($result);
}
?>
<link href="main.css" rel="stylesheet" type="text/css">
<div id="nifty">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="0"><h2 id="mainhead">Update Guild: <?php echo $row["guildname"];?></h2></td>
    <td align="right" valign="top">
</td></tr></table><hr align=left width=250px noshade>
<div style="margin-left: 10px">
<form action="edit_guild.php" method="post">
	Guild Leader: <input type="text" name="leader" size="10" maxlength="20" value="<?php echo $row["guildlead"];?>"  /><Br /><br />
	Guild Website: <input type="text" name="website" size="20" maxlength="256" value="<?php echo $row["guildsite"];?>" /><hr />
	<span class="style1">Change Password:  If you do not wish to change your password, please leave this blank.</span><Br />
	<Br />
    New Password <input type="password" name="password1" size="10" maxlength="20" /><br /><br />
	Confirm Password: <input type="password" name="password2" size="10" maxlength="20" /><br /><Br /><Br />
	<input type="submit" name="submit" value="Submit" />
	<input type="hidden" name="submitted" value="TRUE" />
</form>
<?php 	mysql_close(); // Close the database connection. ?>
</div>
<b class="rbottom"><b class="r4"></b><b class="r3"></b><b class="r2"></b><b class="r1"></b></b></div>


