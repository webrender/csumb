<?php # User is redirected here from guilds.php.
session_start(); // Start the session.

// If no session value is present, redirect the user.
if (!isset($_SESSION['user_id'])) {

	// Start defining the URL.
	$url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
	// Check for a trailing slash.
	if ((substr($url, -1) == '/') OR (substr($url, -1) == '\\') ) {
		$url = substr ($url, 0, -1); // Chop off the slash.
	}
	$url .= '/index.php'; // Add the page.
	header("Location: $url");
	exit(); // Quit the script.
}

// Create the form.
require_once('./config.php'); // Connect to the db.
	
// Create a function for escaping the data.
	function escape_data ($data) {
		global $dblink; // Need the connection.
		if (ini_get('magic_quotes_gpc')) {
			$data = stripslashes($data);
		}
		return mysql_real_escape_string(trim($data), $dblink);
} // End of function.
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Lightninghoof PvE Rankings</title>
<style type="text/css"> 	
body{
	padding: 20px;
	background-color: #000000;
	font: 11px "Trebuchet MS",Verdana,Arial,sans-serif;
	background-image: url(rankingbg.jpg);
	/**background:url(./images/<?= "gentlemansun".rand(1,8).".jpg"; ?>);**/
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
h1,h2,p{margin: 0 10px}
h1{font-size: 250%;color: #FFF}
h2{font-size: 200%;color: #f0f0f0}
.subtitle{font-size: 150%;color: #FFF}
p{padding-bottom:1em;color: #FFF}
h2{padding-top: 0.3em}
img{}
div#nifty{
	background: #000000;
	opacity:.80;
	width:90%;
	filter:alpha(opacity=80);
	margin-top: -20px;
	margin-right: 5%;
	margin-left: 5%;
}
img {
	text-align: center;
	margin: 5px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
div#nifty2{ 
	margin: 0 5%;
	background: #000000;
	width:90%;
}
b.rtop, b.rbottom{display:block;background: #461A3A}
b.rtop b, b.rbottom b{display:block;height: 1px;
    overflow: hidden; background: #000000}
b.r1{margin: 0 5px}
b.r2{margin: 0 3px}
b.r3{margin: 0 2px}
b.rtop b.r4, b.rbottom b.r4{margin: 0 1px;height: 2px}
body,td,th {
	font-size: 11px;
	color: #FFFFFF;
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
td:a:link {
	color: #FF9900;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FF9900;
}
a:hover {
	text-decoration: underline;
	color: #FF9900;
}
a:active {
	text-decoration: none;
	color: #FF9900;
}

a.info{
    position:relative; /*this is the key*/
    z-index:24; 
	/*background-color:#000;*/
    color:#FFF;
    text-decoration:none
	font-size: 50%
	}

a.info:hover{z-index:25; background-color:#FF9900}

a.info span{display: none}

a.info:hover span{ /*the span will display just on :hover state*/
    display:block;
    position:absolute;
    top:1em; left:0em; width:20em;
    border:1px solid #666;
    background-color:#FFF; color:#000;
    text-align: center}
.style1 {color: #FF3300 !important}
.centered {
	text-align: center;
}
</style>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
</head>
<body>
<div id="nifty">
<b class="rtop"><b class="r3"></b></b>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="50%"><h1>Lightninghoof Server Info 2.0</h1></td>
    <td width="50%" align="right" valign="top">
    <span class=subtitle> Welcome, <?php echo "{$_SESSION['user_id']}!"?></span><span class="style1"> | <a href="#" onclick="MM_openBrWindow('edit_guild.php','update','width=350,height=300')">Edit Info</a> | <a href=index_logout.php>Logout.</a></span>
  </td>
  </tr>
</table>
<b class="rtop"><b class="r2"></b></b>
<p>Hosted by <a href="http://www.techotter.com"><u>techotter.com</u></a> - More features coming soon! <b class="rtop"><b class="r4"></b></b><br />
  <span class="style1">New!</span>Check out the new <a href="#photostream"><u>Lightninghoof photostream</u></a> at the bottom of the page!</p>
<p> Hover over a guild name to see guild info.  Click a guild name to see the Armory Profile.<br />
  Hover over a boss' abbreviation to see that boss' full name.</p>
<?php
	$query = "SELECT bossname, instancename, bossorder, points, bossid FROM bosses ORDER BY bossid";		
	$result = @mysql_query ($query); // Run the query.
?>
<table width="100%" border="0" cellspacing="1" cellpadding="0">
<tr>  
<td colspan="4" width="400">Guild Name </td>
<?php
$bg = '#333333'; // Set the background color.
while ($bosses = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$bg = ($bg=='#333333' ? '#666666' : '#333333'); // Switch the background color
	echo '<td width="20" bgcolor=' . $bg . ' align=center><a href="#" class="info">';
	echo substr($bosses['bossname'], 0, 3);
	echo '<span>' . $bosses['bossname'] . '</span></a></td>';
}
?>

<td align="center">Total</td>
</tr>
<tr>
<?php	
	$sessionuserid = $_SESSION['user_id'];
	$query1 = "SELECT isAdmin FROM guilds WHERE (username='$sessionuserid')";
	$result1 = @mysql_query ($query1); // Run the query.
	while ($row = mysql_fetch_array($result1, MYSQL_ASSOC)) {
	$isAdmin = $row['isAdmin'];
	}
	$query2 = "SELECT guildname, guildlead, faction, username, points, guildsite, userid FROM guilds WHERE (isAdmin='0') ORDER BY points DESC";		
	$result2 = @mysql_query ($query2); // Run the query.
	$rank = 1;
	while ($row = mysql_fetch_array($result2, MYSQL_ASSOC)) {
	$bg = '#eeeeee'; // Set the background color.
	if ($row['username'] == $_SESSION['user_id']) {
			$bg='#FFCC33';
	} elseif ($row['faction'] == 'horde') {
			$bg='#990000';
		} else {
			$bg='#0033CC';
		}
	echo '<td colspan="4" bgcolor='	. $bg . '><a href="' . $row['guildsite'] . '" class="info">' . $rank . '. ' .$row['guildname'] . '<span>' . $row['guildsite'] . '<br>Guild Leader:' . $row['guildlead'] . '</span></a></td>';
	
	
	$bossid = 1;

	$query3 = "SELECT bossid FROM bosses ORDER BY bossid";	
	$result3 = @mysql_query ($query3); // Run the query.
	while ($bosses = mysql_fetch_array($result3, MYSQL_ASSOC)) {
		echo '<td bgcolor="' . $bg . '"><div align="center">';
		$bossid = $bosses['bossid'];
		$query4 = "SELECT killid, dateentered FROM kills WHERE (guildid='" . $row['userid'] . "') AND (bossid='" . $bosses['bossid'] . "')";
			
		$result4 = @mysql_query ($query4); // Run the query.
		if($bosses = mysql_fetch_array($result4)) {//check for kill	
      		echo '<a href="#" onclick="MM_openBrWindow(\'view_kill.php?killid=' . $bosses['killid'] . '\',\'update\',\'width=800,height=500\')"><img src=images/green.gif border=0></a>';
    	} else {
			if ($_SESSION['user_id'] == $row['username']) {
      			echo '<a href="#" onclick="MM_openBrWindow(\'edit_kill.php?bossid=' . $bossid . '&userid=' . $row['userid'] . '\',\'update\',\'width=400,height=200\')"><img src=images/red.gif border=0></a>';
			} elseif ($isAdmin == '1') {
				echo '<a href="#" onclick="MM_openBrWindow(\'edit_kill.php?bossid=' . $bossid . '&userid=' . $row['userid'] . '\',\'update\',\'width=400,height=200\')"><img src=images/red.gif border=0></a>';
			} else {
				echo '';
			}
		}	
		echo '</div></td>';
	}
	echo '<td bgcolor="' . $bg . '" align=center>' . $row['points'] . '</td>';
	echo '</tr>';
	$rank = $rank + 1;
	if ($bracket == 9) {
		$bracket = 0; 
		$bg = '#333333'; // Set the background color.
		$query = "SELECT bossname, instancename, bossorder, points, bossid FROM bosses ORDER BY bossid";		
		$result = @mysql_query ($query); // Run the query.
		echo '<tr>';
		echo '<td colspan="4" width="400">Guild Name </td>';
		while ($bosses = mysql_fetch_array($result, MYSQL_ASSOC)) {
			$bg = ($bg=='#333333' ? '#666666' : '#333333'); // Switch the background color
			echo '<td width="20" bgcolor=' . $bg . ' align=center><a href="#" class="info">';
			echo substr($bosses['bossname'], 0, 3);
			echo '<span>' . $bosses['bossname'] . '</span></a></td>';
		}
		echo '</tr>';
	} else {
		$bracket = $bracket + 1; 
		}
	}
?>
</table>
<hr />
<b class="rbottom"><b class="r4"></b><b class="r3"></b><b class="r2"></b><b class="r1"></b></b></div>
<div id="nifty2">
<b class="rtop"><b class="r3"></b></b>
<h1><a name="photostream" id="photostream">Lightninghoof Photostream <b class="rtop"><b class="r2"></b></b></h1>
<p><strong>How to submit screenshots:</strong> email your screenshots as attachments to <a href="mailto:paste07above@photos.flickr.com"><u>paste07above@photos.flickr.com</u></a> It may take a few minutes for the photostream to process your screenshot. <b>ONLY ONE SCREENSHOT PER EMAIL PLEASE :)</b></p>
<p class="style1">NOTE: Screenshots only please. This stream will be monitored, and other images will be removed.  </p><br />

<p class="centered"><script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=9&display=latest&size=m&layout=h&source=user&user=7636238%40N02"></script></p>
<b class="rbottom"><b class="r4"></b><b class="r3"></b><b class="r2"></b><b class="r1"></b></b>
</div>
</body>
</html>
