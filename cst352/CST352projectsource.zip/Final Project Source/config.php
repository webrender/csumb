<?php

define('SERVER','localhost');
define('DATABASE','jeremylaskarProject');
define('DBUSER','jeremylaskar');
define('DBPASSWORD','x4kAKK');

$dblink = mysql_connect(SERVER, DBUSER, DBPASSWORD)
	or die("Connect to server failed on server" . SERVER . " with user " . DBUSER);
	
mysql_select_db(DATABASE, $dblink) or die("Database select of" . DATABASE . "failed" . mysql_error($dblink));

?>