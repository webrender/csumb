<html><link href="main.css" rel="stylesheet" type="text/css">
<div id="nifty">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="0"><h2 id="mainhead">Not Allowed</h2></td>
    <td align="right" valign="top">
</td></tr></table><hr align=left width=250px noshade>
<div style="margin-left: 10px" align=center>You have attempted to reach a page which is not allowed.  Please <a href=index.php>login</a> and attempt to access this page again.</div>
<b class="rbottom"><b class="r4"></b><b class="r3"></b><b class="r2"></b><b class="r1"></b></b></div></html>