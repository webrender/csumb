<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Lightninghoof PvE Rankings</title>
<style type="text/css"> 	
body{
	padding: 20px;
	background-color: #000000;
	background-image: url(rankingbg.jpg);
	/**background:url(./images/<?= "gentlemansun".rand(1,8).".jpg"; ?>);**/
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	font-family: "Trebuchet MS", Verdana, Arial, sans-serif;
	font-size: 11px;
}
h1,h2,p{margin: 0 10px}
h1{font-size: 250%;
color: #FFF;
}
h2{font-size: 200%;color: #f0f0f0}
.subtitle{font-size: 150%;color: #FFF}
p{padding-bottom:1em;color: #FFF}
h2{padding-top: 0.3em}
img{}
div#nifty{ 
	margin: 0 5%;
	background: #000000;
	filter:alpha(opacity=80);
}
img {
	text-align: center;
	margin: 5px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
div#nifty2{ 
	margin: 0 5%;
	background: #000000;
	width:90%;
}
b.rtop, b.rbottom{display:block;background: #461A3A}
b.rtop b, b.rbottom b{display:block;height: 1px;
    overflow: hidden; background: #000000}
b.r1{margin: 0 5px}
b.r2{margin: 0 3px}
b.r3{margin: 0 2px}
b.rtop b.r4, b.rbottom b.r4{margin: 0 1px;height: 2px}
body,td,th {
	font-size: 11px;
	color: #FFFFFF;
}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
td:a:link {
	color: #FF9900;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FF9900;
}
a:hover {
	text-decoration: underline;
	color: #FF9900;
}
a:active {
	text-decoration: none;
	color: #FF9900;
}

a.info{
    position:relative; /*this is the key*/
    z-index:24; 
	/*background-color:#000;*/
    color:#FFF;
    text-decoration:none
	font-size: 50%
	}
a.infoblack{
    position:relative; /*this is the key*/
    z-index:24; 
	/*background-color:#000;*/
    color:#000;
    text-decoration:none
	font-size: 50%
}
a.info:hover{z-index:25; background-color:#FF9900}

a.info span{display: none}

a.info:hover span{ /*the span will display just on :hover state*/
    display:block;
    position:absolute;
    top:1em; left:0em; width:20em;
    border:1px solid #666;
    background-color:#FFF; color:#000;
    text-align: center}
.style1 {color: #FF3300 !important}
.centered {
	text-align: center;
}
</style>
<script type="text/JavaScript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
</head>
<body>
<div id="nifty">
<b class="rtop"><b class="r3"></b></b>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="50%"><h1>Gruul the Dragonslayer </h1></td>
    <td width="50%" align="right" valign="top"><span class="subtitle">Welcome, Moonmaster of Sublime! <a href="#" class="style1">Logout.</a></span></td>
  </tr>
</table>
<b class="rtop"><b class="r2"></b></b>
Downed by Sublime - March 3rd, 2007 <a href="index-loggedin.php" class="style1">Back to Home</a>. <br />
  <img src="gruuldown.jpg" width="800" height="509" />
<b class="rbottom"><b class="r4"></b><b class="r3"></b><b class="r2"></b><b class="r1"></b></b>
</div>
</body>
</html>
