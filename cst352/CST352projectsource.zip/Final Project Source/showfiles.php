<?php

// Database connect
require_once '../../config.php';

$query = 'select id,filename,filetype,filesize from kills order by filename';
$result = mysql_query($query,$dblink) or die("Retrieve query failed: $query " . mysql_error());

while (($line = mysql_fetch_assoc($result)) !== false) {
	echo $line['filename'] . ' (' . number_format($line['filesize'] / 1024) . 'K) ' .
	'<a href="getfile.php?id=' . $line['id'] . '">';
	// echo $line['filetype'];
	//See if image/ is part of the file type stored in the database
	if (preg_match('|^image/|',$line['filetype']))
		echo '<img src="getfile.php?id=' . $line['id'] . '&imagekind=T">';
	else
		echo $line['filename'];
	echo '</a><p>';
}	
?>